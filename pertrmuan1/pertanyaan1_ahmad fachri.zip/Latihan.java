public class Latihan {
	public static void main(String[] args) {
		System.out.println("Hello Dasar Pemrograman");
		System.out.println("Saya suka pemrograman");
	}
}